﻿using System;
using System.IO;

namespace StarGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            // Put the location where you want your file to go, end the location with \StarName.txt to generate a text file in that specific location.
            string file = @"";

            // This is customizable based on what you are referring to (for example: shine in SMS 120 shine, etc. Make sure that
            // You put the shine name in between " " and follow it with a comma, unless it is the last item in the list.
            // There is nothing else you need to change in order to customize (unless you need to change "Current Star: ", seen below
            string[] starNames = new string[] {"Gateway", "Good Egg 1", "Good Egg 2", "Good Egg 3", "Honeyhive 1", "Honeyhive 2", "Honeyhive 3", "Loopdeeloop", "Robot Reactor", "Space Junk 1",
            "Space Junk 2", "Space Junk 3", "Sling Pod", "Sweet Sweet", "Battlerock 1", "Space Junk S", "Space Junk C", "Battlerock 2", "Battlerock 3", "Battlerock S", "Battlerock C", "Hurry-Scurry",
            "Bowser 1", "Beach Bowl 1", "Ghostly 1", "Ghostly 2", "Ghostly 3", "Ghostly S", "Ghostly C", "Beach Bowl 2", "Beach Bowl S", "Beach Bowl 3", "Beach Bowl C", "Bubble Breeze",
            "Buoy Base 1", "Airship Armada", "Freezeflame 1", "Freezeflame 2", "Gusty Garden 1", "Freezeflame 3", "Gusty Garden 2", "Freezeflame S", "Freezeflame C", "Gusty Garden S", "Dusty Dune 1",
            "Gusty Garden 3", "Gusty Garden C", "Dusty Dune 2", "Bowser 2", "Gold Leaf 1", "Sea Slide 1", "Sea Slide 2", "Gold Leaf 2", "Sea Slide 3", "Gold Leaf 3", "Gold Leaf S", "Gold Leaf C",
            "Sea Slide S", "Toy Time 1", "Lava Reactor", "Bowser 3", "Gateway P", "Boo's Boneyard", "Good Egg C", "Good Egg L", "Honeyhive C", "Flipswitch", "Good Egg P", "Deep Dark 1", "Deep Dark 2", "Dreadnought 1",
            "Deep Dark 3", "Melty Molten 1", "Deep Dark S", "Deep Dark C", "Dreadnought 2", "Deep Dark P", "Dreadnought 3", "Melty Molten 2", "Dreadnought S", "Dreadnought C", "Melty Molten 3", "Melty Molten S",
            "Dreadnought P", "Matter Splatter", "Melty Molten P", "Snow Cap", "Space Junk P", "Rolling Green", "Battlerock P", "Battlerock L", "Beahc Bowl P", "Buoy Base S", "Ghostly P", "Drip Drop", "Gusty Garden P",
            "Dusty Dune S", "Freezeflame P", "Dusty Dune 3", "Dusty Dune P", "Honeyclimb", "Dusty Dune C", "Dusty Dune G", "Bubble Blast (g)", "Rolling Gizmo (y)", "Loopdeeswoop (b)", "Bigmouth", "Honeyhive L", "Honeyhive P",
            "Sea Slide P", "Toy Time 2", "Gold Leaf P", "Toy Time 3", "Sea Slide C", "Toy Time S", "Toy Time P", "Bonefin", "Toy Time C", "Sand Spiral"};

            // To generate a star, press enter, and ensure nothing has been typed by you already.
            // To exit program, press enter after typing literally anything into the code
            while (true)
            {
                if (Console.ReadLine() == "")
                {
                    Random num = new Random();
                    int rnd = num.Next(0, starNames.Length);
                    Console.Clear();
                    Console.Write(starNames[rnd]);
                    File.WriteAllText(file, "Current Star: " + starNames[rnd]);
                    continue;
                }

                else
                {
                    break;
                }
            }

            // Exit program
            Console.ReadLine();
        }
    }
}
